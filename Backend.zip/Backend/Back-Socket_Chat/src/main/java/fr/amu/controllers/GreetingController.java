package fr.amu.controllers;


import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import fr.amu.models.*;
import fr.amu.services.*;


@Controller
public class GreetingController {
	
	@Autowired
	UserService us;

    @MessageMapping("/hello")
    @SendTo("/topic/greetings")
    public ChatMsg greeting(ChatMsg message) throws Exception {
        Thread.sleep(100); // simulated delay 
        System.out.println("Ca Marche   "+message.getSender());
        return new ChatMsg(message.getContent(),message.getSender());
    }
    
    
    @MessageMapping("/notif")
    @SendTo("/topic/greetings")
    public String Notif(String use) throws Exception {

    	return use; 
    }

    
}
