package fr.amu.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import fr.amu.models.User;
import fr.amu.models.UserRepo;

@Service
public class UserService {
	@Autowired
	UserRepo ur;
	

	
	public User addUser(User user) {
		 return ur.save(user);
	} 
	
	public Boolean getAl(String a,String b) {
		
		for(User user : ur.findAll()) {
			String N=user.getName();
			String P=user.getPassword();
			if((a.equals(N))&&(b.equals(P))) {
				return true;
		}
		}
		
		return false;
	}
	
	
	/*public Boolean getAl(String a,String b) {
		
		for(User user : ur.findAll()) {
			String D=user.getName();
			String C=user.getPassword();
			System.out.println(a+" DIFF "+D);
			if((a.equals("\""+D+"\""))&&(b.equals("\""+C+"\""))) {
				return true;
		}
		}
		
		return false;
	}*/
}
