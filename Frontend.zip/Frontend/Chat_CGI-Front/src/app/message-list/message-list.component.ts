import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { WebSocketAPI } from '../WebSocketAPI';
import {ActivatedRoute} from '@angular/router';
import { FormControl, FormGroup, Validators } from '@angular/forms';

export class User {
  content: string;
  sender:string;
}


@Component({
  selector: 'app-message-list',
  templateUrl: './message-list.component.html',
  styleUrls: ['./message-list.component.scss']
})
export class MessageListComponent implements OnInit {
  @ViewChild('reference') reference: ElementRef;

  public ownerForm: FormGroup;

  messages:User[];
  name:string;
 

  constructor(private webSocketAPI:WebSocketAPI,route: ActivatedRoute) {
    this.name = route.snapshot.paramMap.get('name');
   }

  ngOnInit() {
    this.ownerForm = new FormGroup({
      content: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      sender:new FormControl()
    }); 
   //console.log("Voila : "+JSON.parse(this.notif.name));
  }


  sendMessage(ownerFormValue){
    ownerFormValue.sender=this.name;  
    this.webSocketAPI._send(ownerFormValue);
    this.reference.nativeElement.value = '';
    this.ownerForm = new FormGroup({
      content: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      sender:new FormControl()
    }); 
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.ownerForm.controls[controlName].hasError(errorName);
  }
  public createOwner = (ownerFormValue) => {
    if (this.ownerForm.valid) {
      this.executeOwnerCreation(ownerFormValue);
    }
  }

  private executeOwnerCreation = (ownerFormValue) => {
    let owner: User = {
      content: ownerFormValue.content,
      sender:this.name

    }}

}
