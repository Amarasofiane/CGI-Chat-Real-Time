import { Component, OnInit,Input } from '@angular/core';
import { WebSocketAPI } from '../WebSocketAPI';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {Router} from '@angular/router';


export class User {

  name: string;
  
}

@Component({
  selector: 'app-login-component',
  templateUrl: './login-component.component.html',
  styleUrls: ['./login-component.component.scss']
})
export class LoginComponentComponent implements OnInit {
  public ownerForm: FormGroup;

  constructor(private router: Router,private webSocketAPI:WebSocketAPI) { }

  ngOnInit() {
    this.connect();

    this.ownerForm = new FormGroup({
      name: new FormControl('', [Validators.required]),
    });

  }

  connect(){
    this.webSocketAPI._connect();
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.ownerForm.controls[controlName].hasError(errorName);
  }
  public createOwner = (ownerFormValue) => {
    if (this.ownerForm.valid) {
      this.executeOwnerCreation(ownerFormValue);
    }
  }

  private executeOwnerCreation = (ownerFormValue) => {
    let owner: User = {
      name: ownerFormValue.name,
    }}


  sendMessage(ownerFormValue){

    this.webSocketAPI._sendNotif(ownerFormValue.name);

    setTimeout(()=>{    //<<<---    using ()=> syntax
      this.router.navigate(['message',{name:ownerFormValue.name}],  )
    }, 1000);
  }


 
}
