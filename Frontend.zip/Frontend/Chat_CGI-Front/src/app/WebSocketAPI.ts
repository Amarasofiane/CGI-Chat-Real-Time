import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';


export class WebSocketAPI {
    webSocketEndPoint: string = 'http://localhost:8080/ws';
    topic: string = "/topic/greetings";
    ama:Array<string>=[];
    stompClient: any;
    connected:any="";
    constructor(){
    }
    _connect() {
       

        console.log("Initialize WebSocket Connection");
        let ws = new SockJS(this.webSocketEndPoint);
        this.stompClient = Stomp.over(ws);
        const _this = this;
        _this.stompClient.connect({}, function (frame) {
            _this.stompClient.subscribe(_this.topic, function (sdkEvent) {
                _this.onMessageReceived(sdkEvent);
    
            });
            _this.stompClient.reconnect_delay = 2000;
        });
    };


    

    _disconnect() {
        if (this.stompClient !== null) {
            this.stompClient.disconnect();
        }
        console.log("Disconnected");
    }


    _send(message) {
        console.log("calling logout api via web socket"+ JSON.stringify(message));
        this.stompClient.send("/app/hello", {}, JSON.stringify(message));
    }
    _sendNotif(message) {
        
        console.log("calling logout api via web socket login "+ JSON.stringify(message));
        this.stompClient.send("/app/notif", {}, JSON.stringify(message));
    }

    onMessageReceived(message){
        var data = JSON.parse(message.body);
        const _this = this;
        if(typeof data!=='string'){
            _this.ama.push(data);
        }else 
            _this.connected=data;
    }

  
}
