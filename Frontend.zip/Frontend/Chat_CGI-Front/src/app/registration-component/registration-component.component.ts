import { Component, OnInit } from '@angular/core';
import { WebSocketAPI } from '../WebSocketAPI';
import { LoginComponentComponent } from '../login-component/login-component.component';
import { MessageListComponent } from '../message-list/message-list.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {Router} from '@angular/router';



export class OwnerForCreation {
  name: string;
  lname:string;
  email: string;
  password:string;
  dateOfBirth: Date;
}

@Component({
  selector: 'app-registration-component',
  templateUrl: './registration-component.component.html',
  styleUrls: ['./registration-component.component.scss']
})
export class RegistrationComponentComponent implements OnInit {
  rout:Router;

  public ownerForm: FormGroup;
 
  constructor(private webSocketAPI :WebSocketAPI,private router: Router){

  }
  ngOnInit() {
    this.ownerForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      lname: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      email: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      password: new FormControl('', [Validators.required, Validators.maxLength(60)]),
      dateOfBirth: new FormControl(new Date()),
    });
  }


  public hasError = (controlName: string, errorName: string) =>{
    return this.ownerForm.controls[controlName].hasError(errorName);
  }
  public createOwner = (ownerFormValue) => {
    if (this.ownerForm.valid) {
      this.executeOwnerCreation(ownerFormValue);
    }
  }

  private executeOwnerCreation = (ownerFormValue) => {
    let owner: OwnerForCreation = {
      name: ownerFormValue.name,
      lname:ownerFormValue.lname,
      email: ownerFormValue.email,
      password:ownerFormValue.password,
      dateOfBirth: ownerFormValue.dateOfBirth
    }}

    sendMessage(Owner:OwnerForCreation){
      console.log("ENDPOINT  01");
      // this.webSocketAPI.save(Owner).subscribe(result => console.log("AAAAA"));
    }


  
}
