import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MyMaterialModule } from  './material.module';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { WebSocketAPI } from './WebSocketAPI';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { ToastNotificationsModule } from "ngx-toast-notifications";
import {MatChipsModule} from '@angular/material/chips';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RegistrationComponentComponent } from './registration-component/registration-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { MessageListComponent } from './message-list/message-list.component';




@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponentComponent,
    LoginComponentComponent,
    MessageListComponent
    ],
  imports: [
    BrowserModule,
    HttpClientModule,
    MatChipsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatSnackBarModule,
    MyMaterialModule,
    ToastNotificationsModule.forRoot(),
    RouterModule.forRoot([
      { path: '', redirectTo: '/login', pathMatch: 'full' },
      { path: 'login', component: LoginComponentComponent },
      { path: 'message', component: MessageListComponent},
    ]),

  ],
  providers: [WebSocketAPI],
  bootstrap: [AppComponent]
})
export class AppModule { }

